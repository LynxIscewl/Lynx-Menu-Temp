﻿using LynxMenuTemp.Menu;
using StupidTemplate.Classes;
using StupidTemplate.Mods;
using static StupidTemplate.Settings;

namespace StupidTemplate.Menu
{
    internal class Buttons
    {
        public static ButtonInfo[][] buttons = new ButtonInfo[][]
        {
            new ButtonInfo[] { // Main Mods
                new ButtonInfo { buttonText = "Settings", method =() => SettingsMods.EnterSettings(), isTogglable = false, toolTip = "Opens the main settings page for the menu."},
                new ButtonInfo { buttonText = "Movement", method =() => Categories.Movement(), isTogglable = false, toolTip = ""},
                new ButtonInfo { buttonText = "Visual", method =() => Categories.Visual(), isTogglable = false, toolTip = ""},
                new ButtonInfo { buttonText = "Rig", method =() => Categories.Rig(), isTogglable = false, toolTip = ""},
                new ButtonInfo { buttonText = "Projectile", method =() => Categories.Projectile(), isTogglable = false, toolTip = ""},
                new ButtonInfo { buttonText = "Saftey", method =() => Categories.Safety(), isTogglable = false, toolTip = ""},

            },

            new ButtonInfo[] { // Settings
                new ButtonInfo { buttonText = "Return to Main", method =() => Global.ReturnHome(), isTogglable = false, toolTip = "Returns to the main page of the menu."},
               new ButtonInfo { buttonText = "Right Hand", enableMethod =() => SettingsMods.RightHand(), disableMethod =() => SettingsMods.LeftHand(), toolTip = "Puts the menu on your right hand."},
                new ButtonInfo { buttonText = "Notifications", enableMethod =() => SettingsMods.EnableNotifications(), disableMethod =() => SettingsMods.DisableNotifications(), enabled = !disableNotifications, toolTip = "Toggles the notifications."},
                new ButtonInfo { buttonText = "FPS Counter", enableMethod =() => SettingsMods.EnableFPSCounter(), disableMethod =() => SettingsMods.DisableFPSCounter(), enabled = fpsCounter, toolTip = "Toggles the FPS counter."},
                new ButtonInfo { buttonText = "Disconnect Button", enableMethod =() => SettingsMods.EnableDisconnectButton(), disableMethod =() => SettingsMods.DisableDisconnectButton(), enabled = disconnectButton, toolTip = "Toggles the disconnect button."},
            },

            new ButtonInfo[] { // Movement
                new ButtonInfo { buttonText = "Return to Main", method =() => Global.ReturnHome(), isTogglable = false, toolTip = "Returns to the main page of the menu."},
                new ButtonInfo { buttonText = "regular placeholder", isTogglable = false},
                new ButtonInfo { buttonText = "togglable placeholder"},

            },

             new ButtonInfo[] { // Visual
                new ButtonInfo { buttonText = "Return to Main", method =() => Global.ReturnHome(), isTogglable = false, toolTip = "Returns to the main page of the menu."},
                new ButtonInfo { buttonText = "regular placeholder", isTogglable = false},
                new ButtonInfo { buttonText = "togglable placeholder"},

            },

             new ButtonInfo[] { // Rig
               new ButtonInfo { buttonText = "Return to Main", method =() => Global.ReturnHome(), isTogglable = false, toolTip = "Returns to the main page of the menu."},
               new ButtonInfo { buttonText = "regular placeholder", isTogglable = false},
               new ButtonInfo { buttonText = "togglable placeholder"},

            },

             new ButtonInfo[] { // Projectile
               new ButtonInfo { buttonText = "Return to Main", method =() => Global.ReturnHome(), isTogglable = false, toolTip = "Returns to the main page of the menu."},
               new ButtonInfo { buttonText = "regular placeholder", isTogglable = false},
               new ButtonInfo { buttonText = "togglable placeholder"},

            },

             new ButtonInfo[] { // Safety
               new ButtonInfo { buttonText = "Return to Main", method =() => Global.ReturnHome(), isTogglable = false, toolTip = "Returns to the main page of the menu."},
               new ButtonInfo { buttonText = "regular placeholder", isTogglable = false},
               new ButtonInfo { buttonText = "togglable placeholder"},

            },

        };
    }
}
