﻿using static StupidTemplate.Menu.Main;
using static StupidTemplate.Settings;

namespace LynxMenuTemp.Menu
{
    class Categories
    {
        public static void Movement()
        {
            buttonsType = 2;
        }
        public static void Visual()
        {
            buttonsType = 3;
        }
        public static void Rig()
        {
            buttonsType = 4;
        }
        public static void Projectile()
        {
            buttonsType = 5;

        }
            public static void Safety()
        {
            buttonsType = 6;
        }
    }
}
