﻿using System;
using System.Collections.Generic;
using System.Text;
using Photon.Pun;
using PlayFab.ClientModels;
using UnityEngine;
using UnityEngine.InputSystem;

namespace LynxMenuTemp.Menu
{
    class Mods
    {

        public static void placeholder()
        {

        }







    }
}
